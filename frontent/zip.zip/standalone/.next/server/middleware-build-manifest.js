globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": [
      "static/chunks/e60ef129113f6e24.js",
      "static/chunks/4ebf409f7ff93d19.js",
      "static/chunks/turbopack-a7eb832222440fbb.js"
    ],
    "/_error": [
      "static/chunks/17722e3ac4e00587.js",
      "static/chunks/4ebf409f7ff93d19.js",
      "static/chunks/turbopack-6b8026a2ed24e315.js"
    ]
  },
  "devFiles": [],
  "ampDevFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/0e88b4b780bf4c60.js",
    "static/chunks/91adb7bdb9870c6a.js",
    "static/chunks/8082ab48faca5ea1.js",
    "static/chunks/c19da6693934fea1.js",
    "static/chunks/2008ffcf9e5b170c.js",
    "static/chunks/turbopack-bc19c4c411fd2f7e.js"
  ],
  "ampFirstPages": []
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
,"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js",

];