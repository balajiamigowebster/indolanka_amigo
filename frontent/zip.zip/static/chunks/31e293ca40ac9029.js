__turbopack_load_page_chunks__("/_app", [
  "static/chunks/e60ef129113f6e24.js",
  "static/chunks/4ebf409f7ff93d19.js",
  "static/chunks/turbopack-a7eb832222440fbb.js"
])
