__turbopack_load_page_chunks__("/_error", [
  "static/chunks/17722e3ac4e00587.js",
  "static/chunks/4ebf409f7ff93d19.js",
  "static/chunks/turbopack-6b8026a2ed24e315.js"
])
